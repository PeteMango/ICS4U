import javafx.application.Application;
import javafx.stage.Stage;

public class Main {
    public static void main(String[] args) {
        Application.launch(GUI.class, args);
    }
}
